import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Server implements Runnable {
    private BlockingQueue<Client> clienti;
    private int waitingTime;
    private int nrMaxClients;

    public int getNrMaxClients() {
        return nrMaxClients;
    }

    public void setNrMaxClients(int nrMaxClients) {
        this.nrMaxClients = nrMaxClients;
    }

    public int getWaitingTime() {
        return waitingTime;
    }

    public void setWaitingTime(Integer waitingTime) {
        this.waitingTime = waitingTime;
    }

    public Server(int nrMaxClients,int waitingTime) {
        this.nrMaxClients = nrMaxClients;
        clienti = new ArrayBlockingQueue<Client>(nrMaxClients);
        this.waitingTime = waitingTime;

    }

    public void addClient(Client c) {
        clienti.add(c);
        waitingTime = waitingTime + 1;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Client c = clienti.take();
                Thread.sleep(c.gettService());
                waitingTime--;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    public BlockingQueue<Client> getClienti() {
        return clienti;
    }
}
