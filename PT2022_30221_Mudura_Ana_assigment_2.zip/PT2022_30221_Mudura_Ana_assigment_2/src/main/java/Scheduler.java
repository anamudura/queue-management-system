import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Scheduler {
    private List<Server> servers;

    public List<Server> getServers() {
        return servers;
    }

    private int MaxServers;
    private int MaxClientsperServer;
    private Strategy strategy;

    public Scheduler(int MaxServers, int MaxClientsperServer) {
        servers = new ArrayList<Server>();
        this.MaxClientsperServer = MaxClientsperServer;
        this.MaxServers = MaxServers;
        for (int i = 1; i < MaxServers; i++) {
            Server s = new Server(MaxClientsperServer,0);
            servers.add(s);
            Thread t = new Thread(s);
            t.start();

        }
        strategy = new ConcreteStrategyTime();
    }
    public void ChangeStratey(SelectionPolicy policy)
    {
        if(policy == SelectionPolicy.SHORTEST_QUEUE)
            strategy = new ConcreteStrategyQueue();
        if(policy == SelectionPolicy.SHORTEST_TIME)
            strategy = new ConcreteStrategyTime();
    }
    public void dispatchClient(Client c, FileWriter f) throws IOException {
        strategy.addClient(servers,c,f);
    }

}
