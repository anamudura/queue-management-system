import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ConcreteStrategyTime implements Strategy {
    @Override
    public void addClient(List<Server> servers, Client c, FileWriter f) throws IOException {
        int min = Integer.MAX_VALUE;
        for (Server s : servers)
            if (s.getWaitingTime() < min)
                min = s.getWaitingTime();
        for (Server s : servers)
            if (s.getWaitingTime() == min) {
                s.addClient(c);
                break;
            }
        int i = 1;
        for(Server s:servers) {
            for (Client p : s.getClienti()) {
                f.write("Queue: " + i + " " + p.getId()+ " "+p.gettArrival()+"\n");

            }
            i++;
        }
    }
}
