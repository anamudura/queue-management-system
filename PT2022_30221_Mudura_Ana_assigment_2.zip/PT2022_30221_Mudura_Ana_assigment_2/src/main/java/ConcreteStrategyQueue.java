import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ConcreteStrategyQueue implements Strategy {
    @Override
    public void addClient(List<Server> servers, Client c,FileWriter f) throws IOException {
    for(Server s: servers)
        if(s.getClienti().size()<s.getNrMaxClients())
            s.addClient(c);
        int i = 1;
        for(Server s:servers) {
            for (Client p : s.getClienti()) {
                f.write("Queue: " + i + " " + p.getId()+ " "+p.gettArrival()+"\n");

            }
            i++;
        }


    }
}

